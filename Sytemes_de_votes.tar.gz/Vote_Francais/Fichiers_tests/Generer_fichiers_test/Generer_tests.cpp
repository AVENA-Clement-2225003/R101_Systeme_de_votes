#include <iostream>
#include <vector>
#include <fstream>
#include <istream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <string>
using namespace std;

unsigned choisirUnAleatoireDifferent(vector<unsigned> & listeDejaVoter, unsigned tailleListeCandidat)
{
    unsigned i;
    bool etat = true;
    bool dejaVoter = true;
    while (etat & dejaVoter) //Tant que le random trouvé de correspond pas au critère demandé on recommence
    {
        dejaVoter = false;
        i = rand()%tailleListeCandidat;
        for (size_t j = 0; j < listeDejaVoter.size(); j+=1) //Permet de verifier si le random produit ne se trouve pas déja parmis ceux déja donné
        {
            if (i == listeDejaVoter[j])
            {
                dejaVoter = true;
                break;
            }
        }
    }
    return i;
}

void fichier(const string nomFichier, const string fichSortie, const unsigned nbCandidat){
    string ligne;
    unsigned vote;
    vector<unsigned> listevote = {};
    string temp;
    ifstream ifs(nomFichier);
    ofstream ofs(fichSortie, ios_base::out|ios_base::app);
    ofs << "Counter Strike (aka CS:GO)#Street Fighter II#Civilisation VI#Mario Kart#" << endl;
    while (true){
        getline(ifs, ligne);        
        if (ifs.eof()) break;
        for (size_t j = 0; j<2; ++j){
            vote = choisirUnAleatoireDifferent(listevote, 4);
            listevote.push_back(vote);
            temp = temp + to_string(vote);
        }
        ofs << ligne + temp << endl;
        temp = "";
        listevote = {};
    }

}

int main()
{
    srand (time(NULL));
    string nomFichier = "Votants.txt";
    string fichSortie;
    cout << "Quel nom a donner pour le fichier ?" << endl;
    cin >> fichSortie;
    fichier(nomFichier, fichSortie, 4);
    return 0;
}

