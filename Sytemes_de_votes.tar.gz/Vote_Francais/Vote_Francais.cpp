#include <iostream>
#include <vector>
using namespace std;

//initialisation

//regarder attribution point

vector <unsigned> tabCandidats;  //tableau indice candidat
vector <string> candidat(0);   //tableau nom candidat
unsigned nbVotants = 0;  //nombre de votants (ou nb de vote)
vector<unsigned> tabCandidats2(4, 0); // nombre de voix de chaque candidat au second tour

void recupCandidat(const string & noms){ //procedure qui crée un vector candidat contenant la liste des candidats
    string temp;
    for (size_t i = 0; i<noms.size(); ++i){
        if (noms[i] == '#'){
            candidat.push_back(temp);
            temp = "";
        }
        else {
            temp += noms[i];
        }
    }
}

void mettreBonneTaille() //procedure mettant le tableau tabCandidats à la bonne taille
{
    tabCandidats.resize(candidat.size());
}

vector<size_t> chercherIndice(const vector<unsigned> & tabCand)
{
    size_t iMax(0);
    size_t iSousMax(0);

    for(size_t i = 0; i < tabCand.size(); i+=1)
    {
        if (tabCand[i] >= tabCand[iMax])
        {
            iSousMax = iMax;
            iMax = i;
        }
    }
    if (iMax == 0 && iSousMax == 0)
    {
        iSousMax = 1;
        for(size_t i = 1; i < tabCand.size(); i+=1)
        {
            if (tabCand[i] >= tabCand[iSousMax])
            {
                iSousMax = i;
            }
        }
    }
    return {iMax, iSousMax};
}

//premierTour
void VotePremierTour(const string & ligne) //comptabilise les votes du premier tour
{
   unsigned indice = ligne[ligne.size()-2]-'0';
   tabCandidats[indice] += 1;
}

bool quiPasseAuSecondTour() //regarde le nb de vote et determine qui passe au second ou gagne à la majo absolue
{
    bool faire2eTour = true;
    vector <size_t> indiceGagnants = chercherIndice(tabCandidats);
    cout << "Voix :" << endl;
    for (size_t i = 0; i < tabCandidats2.size(); ++i)
    {
        cout << candidat[i] << ": " << tabCandidats[i] << endl;
    }
    if (tabCandidats[indiceGagnants[0]]>(nbVotants/2))
    {
        cout << "Le candidat élu est: " << candidat[indiceGagnants[0]] << " à la majorité absolue";
        faire2eTour = false;
    }
    else
    {
        cout << "Le premier candidat voté pour le second tour est: " << candidat[indiceGagnants[0]] << endl;
        cout << "Le deuxieme candidat voté pour le second tour est: " << candidat[indiceGagnants[1]] << endl;
    }
    return faire2eTour;
}

//secondTour
void VoteSecondTour(string ligne) //comptabilise les votes du second tour
{
    unsigned indice = ligne[ligne.size()-1]-'0';
    tabCandidats2[indice]+=1;
}

void quiEstElu(vector<unsigned> tabCandidats2) //regarde le nb de votes et déclare le vainqueurs
{
    vector<size_t> tmp = chercherIndice(tabCandidats2);
    cout<<"Voix :"<<endl;
    for (size_t i=0; i<tabCandidats2.size(); ++i)
    {
        cout<<candidat[i] <<": "<< tabCandidats2[i]<< endl;
    }
    cout<<"Le candidat qui a gagné l'election est "<<candidat[tmp[0]]<<endl;
}

int main()
{
    string ligne;
    getline(cin,ligne);
    recupCandidat(ligne);
    mettreBonneTaille();
    vector<string> toutesLesLignes (0);
    while(true)
    {
        nbVotants+=1;
        getline(cin,ligne);
        if (cin.eof()) break;
        VotePremierTour(ligne);
        toutesLesLignes.push_back(ligne);
    }
    if(quiPasseAuSecondTour())
    {
        for (size_t i = 0; i<toutesLesLignes.size(); ++i)
        {
            VoteSecondTour(toutesLesLignes[i]);
        }
        quiEstElu(tabCandidats2);
    }
    return 0;
}
