#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

vector<unsigned> extraireVote(string & votant) //Fonction permettant de recuperer un vecteur contenant les vote de l'élève
{
    vector<unsigned> votes = {};
    bool estCeVotes = false;
    unsigned a;
    for(size_t i = 0; i < votant.size(); i+=1)
    {
        if(votant[i] == '#')
        {
            estCeVotes = true;
            continue;
        }
        if(estCeVotes)
        {
            a = votant[i];
            votes.push_back(a-'0');
        }
    }
    unsigned choix = votant[votant.size()-5];
    votes.push_back(choix);
    return votes;
}

void voter(vector<unsigned> & listePoints, const vector<unsigned> & vote) //Procédure permettant de donner les points aux candidats
{
    for(size_t i = 0; i < vote.size(); i+=1)
    {
        listePoints[i] += vote[i];
    }
}

int main()
{
    string strCandidats;
    vector<string> listeCandidats;
    string strDecoupage ="";
    getline(cin, strCandidats);                         
    for(size_t i = 0; i < strCandidats.size(); i+=1)    //
    {                                                   //
        if(strCandidats[i] == '#')                      //
        {                                               //
            listeCandidats.push_back(strDecoupage);     //  Récupération de la liste des candidats
            strDecoupage = "";                          //
            continue;                                   //
        }                                               //
        strDecoupage += strCandidats[i];                //
    }                                                   //
    string votant;
    vector<unsigned> votes;
    vector<unsigned> pointsCandidats;
    pointsCandidats.resize(listeCandidats.size());
    while (true) //Voter tant qu'il y a des votants
    {
        getline(cin, votant);
        if (cin.eof()){break;}
        votes = extraireVote(votant);
        voter(pointsCandidats, votes);
    }
    for(size_t i = 0; i < pointsCandidats.size(); i+=1)
    {
        cout << listeCandidats[i] << " : " << pointsCandidats[i] << " points" << endl; //Affichage des candidats avec leurs points une fois le vote terminé
    }
    size_t indiceVainqueur = 0;
    for(size_t i = 1; i < pointsCandidats.size(); i+=1)
    {                                                                                   //
        if(pointsCandidats[i] > pointsCandidats[indiceVainqueur]){indiceVainqueur = i;} // Recherche de l'indice du vainqueur
    }                                                                                   //
    cout << "le vainqueur est " << listeCandidats[indiceVainqueur] << " avec " <<  pointsCandidats[indiceVainqueur] << " points";
    return 0;
}
