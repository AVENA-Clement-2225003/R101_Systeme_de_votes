#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

vector <string> recupCandidat() // Fonction permettant la récupération de la liste des candidats
{
    vector <string> candidat(0);
    string ligne;
    string temp;
    getline(cin, ligne);
    for(size_t i = 0; i<ligne.size(); ++i)
    {
        if(ligne[i] == '#')
        {
            candidat.push_back(temp);
            temp = "";
        }
        else
        {
            temp += ligne[i];
        }
    }
    return candidat;
}

int main()
{
    char caract;
    unsigned vote;
    vector<string> candidat = recupCandidat();
    vector<unsigned> resultat(candidat.size(), 0);
    while(true) //Chaque personne vote
    {
        cin.get(caract);
        vote = caract-'0';
        if(cin.eof()) break;
        for(size_t i = 0; i < candidat.size(); ++i)
        {
            if(vote-1 == i)
            {

                resultat[i]+=1;
            }
        }
    }
    for(size_t i = 0; i < candidat.size(); ++i) //Affichage des candidats et de leur voix
    {
        cout << candidat[i] << " : " << resultat[i] << " voix" << endl;
    }
    return 0;
}


