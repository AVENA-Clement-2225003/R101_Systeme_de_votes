#include <iostream>
#include <vector>

using namespace std;

vector <string> recupCandidat(const string & noms){
    vector <string> candidat (0);
    string temp;
    for (size_t i = 0; i<noms.size(); ++i){
        if (noms[i] == '#'){
            candidat.push_back(temp);
            temp = "";
        }
        else {
            temp += noms[i];
        }
    }
    cout << "Liste des candidats : " << endl;
    for (size_t i = 0; i<candidat.size(); ++i) {
        cout << candidat[i] << endl;
    }
    return candidat;
}

string recupVotes(const string & ligne){
    string vote;
    size_t compteur = 0 ;
    while (ligne[compteur] != '#'){
        ++compteur;
    }
    ++compteur;
    for (compteur ; compteur<ligne.size(); ++compteur){
        vote += ligne[compteur];
    }
    return vote;
}

vector <string> lireFichier(){
    string ligne;
    vector <string> noms(0);
    while (true){
        getline(cin, ligne);
        if (cin.eof()) break;
        noms.push_back(ligne);
    }
    return noms;
}

vector <unsigned> compterVotes(const vector <string> & votes, vector <unsigned> & voix){
    for (size_t i = 0; i<votes.size(); ++i){
        for (size_t j = 0; j<votes[i].size(); ++j){
            if (votes[i][j] == '1'){
                voix[j] +=1;
            }
        }
    }
    return voix;
}

size_t trouverGagnant(const vector <unsigned> & voixCandidats){
    size_t indicePlusGrand = 0;
    for (size_t i = 1; i<voixCandidats.size(); ++i){
        if (voixCandidats[i] > voixCandidats[indicePlusGrand]){
            indicePlusGrand = i;
        }
    }
    return indicePlusGrand;
}

void afficherLeGagnant(const vector <string> & candidat, const size_t & indiceGagnant, const vector <unsigned> voixCandidats){
    // Declare le gagnant en foncion de son indice
    cout << "Le gagnant est... " << candidat[indiceGagnant] << " avec "
         << voixCandidats[indiceGagnant] << " points." <<endl;
}

int main()
{
    vector <string> noms;
    noms = lireFichier();
    vector <string> tabCandidat;
    tabCandidat = recupCandidat(noms[0]);
    vector <string> votes (noms.size());
    for (size_t i = 1; i<noms.size(); ++i){
        votes[i] = recupVotes(noms[i]);
    }
    vector <unsigned> voixCandidats (tabCandidat.size(), 0);
    voixCandidats = compterVotes(votes, voixCandidats);
    for (size_t i = 0; i<voixCandidats.size(); ++i){
        cout << tabCandidat[i] << " : " << voixCandidats[i] << endl;
    }
    size_t indiceDuGagnant = trouverGagnant(voixCandidats);
    afficherLeGagnant(tabCandidat, indiceDuGagnant, voixCandidats);
    return 0;
}
